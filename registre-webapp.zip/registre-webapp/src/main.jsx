import React from "react";
import ReactDOM from "react-dom/client";
import "./storage.js"; // branche window.storage sur Supabase avant tout le reste
import App from "./App.jsx";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
