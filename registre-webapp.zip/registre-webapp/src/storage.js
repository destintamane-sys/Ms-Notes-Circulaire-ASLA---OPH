// Cette couche remplace le "window.storage" fourni par l'environnement Claude.
// Elle reproduit exactement la même interface (get / set / delete / list) mais
// enregistre réellement les données dans une base Supabase, pour que rien
// d'autre dans l'application n'ait besoin d'être modifié.
//
// Configuration nécessaire (voir GUIDE-MISE-EN-LIGNE.md) :
//   VITE_SUPABASE_URL       -> l'URL de ton projet Supabase
//   VITE_SUPABASE_ANON_KEY  -> la clé publique ("anon") de ton projet Supabase
//
// Sans ces deux variables, l'application fonctionne quand même (mode démo)
// mais oublie tout au rechargement de la page.

import { createClient } from "@supabase/supabase-js";

const TABLE = "registre_kv";

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL;
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY;

let supabase = null;
if (SUPABASE_URL && SUPABASE_ANON_KEY) {
  supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
} else {
  console.warn(
    "[Registre] Variables Supabase absentes — les données ne seront pas sauvegardées. " +
      "Suis le GUIDE-MISE-EN-LIGNE.md pour activer la sauvegarde permanente."
  );
}

// ---- repli en mémoire (mode démo, sans Supabase) ----
const memoryStore = new Map();

async function memGet(key) {
  if (!memoryStore.has(key)) throw new Error("not found");
  return { key, value: memoryStore.get(key) };
}
async function memSet(key, value) {
  memoryStore.set(key, value);
  return { key, value };
}
async function memDelete(key) {
  memoryStore.delete(key);
  return { key, deleted: true };
}
async function memList(prefix = "") {
  return { keys: [...memoryStore.keys()].filter((k) => k.startsWith(prefix)) };
}

// ---- implémentation Supabase ----
async function sbGet(key) {
  const { data, error } = await supabase.from(TABLE).select("value").eq("key", key).maybeSingle();
  if (error) throw error;
  if (!data) throw new Error("not found");
  return { key, value: data.value };
}
async function sbSet(key, value) {
  const { error } = await supabase.from(TABLE).upsert({ key, value, updated_at: new Date().toISOString() });
  if (error) throw error;
  return { key, value };
}
async function sbDelete(key) {
  const { error } = await supabase.from(TABLE).delete().eq("key", key);
  if (error) throw error;
  return { key, deleted: true };
}
async function sbList(prefix = "") {
  const { data, error } = await supabase.from(TABLE).select("key").ilike("key", `${prefix}%`);
  if (error) throw error;
  return { keys: (data || []).map((r) => r.key) };
}

export const storage = {
  get: (key) => (supabase ? sbGet(key) : memGet(key)),
  set: (key, value) => (supabase ? sbSet(key, value) : memSet(key, value)),
  delete: (key) => (supabase ? sbDelete(key) : memDelete(key)),
  list: (prefix) => (supabase ? sbList(prefix) : memList(prefix)),
};

if (typeof window !== "undefined") {
  window.storage = storage;
}
