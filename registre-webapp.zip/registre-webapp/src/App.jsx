import React, { useState, useEffect, useRef, useMemo, useCallback } from "react";
import mammoth from "mammoth";
import {
  Upload, Search, BookOpen, Layers, Link2, Image as ImageIcon,
  X, ChevronLeft, ArrowLeft, Plus, Trash2, FileText, Loader2,
  CornerDownRight, LibraryBig, AlertCircle, Check
} from "lucide-react";

/* ---------------------------------------------------------------
   Design tokens
   Palette   — registre d'archives : papier vieilli, encre tamponnée
     paper      #E7DFC6   fond général
     card       #F6F1E3   surfaces / fiches
     ink        #2A2417   texte principal
     inkFaint   #7C7355   texte secondaire
     stamp      #8A2E2E   accent principal (liens, tampons)
     ledger     #3F5142   accent secondaire (rangement, badges "lu")
     hairline   #C9BE9C   séparateurs
   Type
     display    "Source Serif 4"  (titres, façon manuscrit administratif)
     utility    "IBM Plex Mono"   (codes NC, dates, métadonnées)
     body       "Source Serif 4"  (contenu, lecture longue)
   Signature — chaque fiche porte un "tampon" (badge circulaire encré)
   affichant son code, comme un cachet de registre.
------------------------------------------------------------------*/

const FONT_LINK_ID = "archive-wiki-fonts";
function ensureFonts() {
  if (document.getElementById(FONT_LINK_ID)) return;
  const link = document.createElement("link");
  link.id = FONT_LINK_ID;
  link.rel = "stylesheet";
  link.href =
    "https://fonts.googleapis.com/css2?family=Source+Serif+4:ital,opsz,wght@0,8..60,400;0,8..60,600;0,8..60,700;1,8..60,400&family=IBM+Plex+Mono:wght@400;500;600&display=swap";
  document.head.appendChild(link);
}

const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);

// --- normalisation de code (pour la détection d'en-têtes et de renvois croisés) ---
// Reconnaît les formats rencontrés dans les archives ASLA :
//   NC 007/GELC/...          -> NC007
//   N° 001/G.E.L.C./...      -> N001
//   Décision N° 003/...      -> DEC003
//   DOC 1980 / Doc 1995      -> DOC1980
const CODE_G_SOURCE =
  "(?:D[ée]cision|DECISION)\\s+N\\s*°?\\s*0*(\\d{1,4})" + // Décision N° xxx
  "|NC\\s*0*(\\d{1,4})" + // NC xxx
  "|N\\s*°\\s*0*(\\d{1,4})" + // N° xxx
  "|(?:DOC|Doc)\\s*0*(\\d{1,4})"; // Doc xxxx

function codeFromMatch(m) {
  if (m[1] != null) return `DEC${m[1]}`;
  if (m[2] != null) return `NC${m[2]}`;
  if (m[3] != null) return `N${m[3]}`;
  if (m[4] != null) return `DOC${m[4]}`;
  return null;
}
function normalizeCode(str) {
  if (!str) return null;
  const re = new RegExp(CODE_G_SOURCE, "i");
  const m = re.exec(str);
  return m ? codeFromMatch(m) : null;
}
function allCodesIn(text) {
  const re = new RegExp(CODE_G_SOURCE, "gi");
  const out = [];
  let m;
  while ((m = re.exec(text)) !== null) {
    out.push({ code: codeFromMatch(m), index: m.index, raw: m[0], length: m[0].length });
  }
  return out;
}

// --- découpage d'un texte brut en fiches ---
function splitIntoEntries(rawText, mode) {
  const lines = rawText.split(/\r?\n/).map((l) => l.trim());
  const HEADER_RE = new RegExp("^(?:" + CODE_G_SOURCE + "|Note\\s+Circulaire\\s*\\d|Circulaire\\s*\\d)", "i");

  if (mode === "whole") {
    const content = lines.filter(Boolean).join("\n");
    return [{ id: uid(), code: "", title: "Document entier", content, order: 0, imageIds: [] }];
  }

  if (mode === "paragraph") {
    const entries = [];
    let buf = [];
    let order = 0;
    for (const line of lines) {
      if (!line) {
        if (buf.length) {
          const text = buf.join(" ");
          entries.push({
            id: uid(),
            code: normalizeCode(text) || "",
            title: text.slice(0, 70) + (text.length > 70 ? "…" : ""),
            content: text,
            order: order++,
            imageIds: [],
          });
          buf = [];
        }
      } else buf.push(line);
    }
    if (buf.length) {
      const text = buf.join(" ");
      entries.push({
        id: uid(), code: normalizeCode(text) || "", title: text.slice(0, 70), content: text, order: order++, imageIds: [],
      });
    }
    return entries;
  }

  // mode "auto" — détection d'en-têtes façon NC 007/GELC/... DU date :
  const entries = [];
  let current = null;
  let order = 0;
  for (const line of lines) {
    if (!line) continue;
    const looksLikeHeader =
      HEADER_RE.test(line) || (line.length < 90 && /[:：]\s*$/.test(line) && line === line.toUpperCase() === false && /^[A-ZÀ-Ü0-9]/.test(line));
    if (HEADER_RE.test(line)) {
      if (current) entries.push(current);
      current = {
        id: uid(),
        code: normalizeCode(line) || "",
        title: line.replace(/[:：]\s*$/, ""),
        content: [],
        order: order++,
        imageIds: [],
      };
    } else {
      if (!current) {
        current = { id: uid(), code: "", title: line.slice(0, 70), content: [], order: order++, imageIds: [] };
      }
      current.content.push(line);
    }
  }
  if (current) entries.push(current);
  return entries.map((e) => ({ ...e, content: Array.isArray(e.content) ? e.content.join("\n") : e.content }));
}

// --- rendu d'un texte avec renvois cliquables ---
function LinkedText({ text, codeMap, currentEntryId, onNavigate }) {
  if (!text) return null;
  const parts = [];
  let lastIndex = 0;
  const re = new RegExp(CODE_G_SOURCE, "gi");
  let m;
  let key = 0;
  while ((m = re.exec(text)) !== null) {
    const norm = codeFromMatch(m);
    const target = norm ? codeMap.get(norm) : null;
    if (target && target.id !== currentEntryId) {
      if (m.index > lastIndex) parts.push(<span key={key++}>{text.slice(lastIndex, m.index)}</span>);
      parts.push(
        <button
          key={key++}
          onClick={() => onNavigate(target.id)}
          className="ref-link"
          title={target.title}
        >
          {m[0]}
        </button>
      );
      lastIndex = re.lastIndex;
    }
  }
  parts.push(<span key={key++}>{text.slice(lastIndex)}</span>);
  return <>{parts}</>;
}

export default function ArchiveWikiReader() {
  useEffect(ensureFonts, []);

  const [docs, setDocs] = useState([]); // {id, title, importedAt, entries:[...]}
  const [images, setImages] = useState({}); // id -> {id, docId, name, dataUrl}
  const [loaded, setLoaded] = useState(false);
  const [activeDocId, setActiveDocId] = useState(null);
  const [activeEntryId, setActiveEntryId] = useState(null);
  const [mode, setMode] = useState("wiki"); // "wiki" | "lecture"
  const [search, setSearch] = useState("");
  const [showImport, setShowImport] = useState(false);
  const [history, setHistory] = useState([]); // pile de navigation (wiki mode)
  const [toast, setToast] = useState(null);
  const [storageOk, setStorageOk] = useState(true);

  const flash = (msg) => {
    setToast(msg);
    window.clearTimeout(flash._t);
    flash._t = window.setTimeout(() => setToast(null), 2600);
  };

  // ---------- persistance ----------
  useEffect(() => {
    (async () => {
      try {
        const idx = await window.storage.get("doc-index").catch(() => null);
        const ids = idx ? JSON.parse(idx.value) : [];
        const loadedDocs = [];
        for (const id of ids) {
          try {
            const d = await window.storage.get(`doc:${id}`);
            loadedDocs.push(JSON.parse(d.value));
          } catch {}
        }
        loadedDocs.sort((a, b) => (a.importedAt < b.importedAt ? 1 : -1));
        setDocs(loadedDocs);
        if (loadedDocs[0]) setActiveDocId(loadedDocs[0].id);

        const imgList = await window.storage.list("image:").catch(() => null);
        if (imgList && imgList.keys) {
          const imgMap = {};
          for (const k of imgList.keys) {
            try {
              const r = await window.storage.get(k);
              const val = JSON.parse(r.value);
              imgMap[val.id] = val;
            } catch {}
          }
          setImages(imgMap);
        }
      } catch (e) {
        setStorageOk(false);
      }
      setLoaded(true);
    })();
  }, []);

  const persistDoc = useCallback(async (doc) => {
    try {
      await window.storage.set(`doc:${doc.id}`, JSON.stringify(doc));
    } catch {
      setStorageOk(false);
    }
  }, []);

  const persistIndex = useCallback(async (list) => {
    try {
      await window.storage.set("doc-index", JSON.stringify(list.map((d) => d.id)));
    } catch {
      setStorageOk(false);
    }
  }, []);

  // ---------- dérivés ----------
  const activeDoc = docs.find((d) => d.id === activeDocId) || null;
  const codeMap = useMemo(() => {
    const map = new Map();
    if (activeDoc) {
      for (const e of activeDoc.entries) {
        const norm = e.code || normalizeCode(e.title);
        if (norm) map.set(norm, e);
      }
    }
    return map;
  }, [activeDoc]);

  const backlinks = useMemo(() => {
    if (!activeDoc || !activeEntryId) return [];
    const target = activeDoc.entries.find((e) => e.id === activeEntryId);
    if (!target) return [];
    const norm = target.code || normalizeCode(target.title);
    if (!norm) return [];
    return activeDoc.entries.filter(
      (e) => e.id !== activeEntryId && allCodesIn(e.content).some((c) => c.code === norm)
    );
  }, [activeDoc, activeEntryId]);

  const filteredEntries = useMemo(() => {
    if (!activeDoc) return [];
    const q = search.trim().toLowerCase();
    const list = [...activeDoc.entries].sort((a, b) => a.order - b.order);
    if (!q) return list;
    return list.filter(
      (e) => e.title.toLowerCase().includes(q) || e.content.toLowerCase().includes(q) || (e.code || "").toLowerCase().includes(q)
    );
  }, [activeDoc, search]);

  const activeEntry = activeDoc?.entries.find((e) => e.id === activeEntryId) || null;

  // ---------- navigation ----------
  const goToEntry = (id, pushHistory = true) => {
    if (pushHistory && activeEntryId) setHistory((h) => [...h, activeEntryId]);
    setActiveEntryId(id);
    setMode("wiki");
  };
  const goBack = () => {
    setHistory((h) => {
      if (!h.length) return h;
      const next = [...h];
      const prev = next.pop();
      setActiveEntryId(prev);
      return next;
    });
  };

  const selectDoc = (id) => {
    setActiveDocId(id);
    const d = docs.find((x) => x.id === id);
    setActiveEntryId(d?.entries?.[0]?.id || null);
    setHistory([]);
    setSearch("");
  };

  // ---------- import ----------
  const [importState, setImportState] = useState({ status: "idle" }); // idle | parsing | preview | error
  const [importPreview, setImportPreview] = useState(null);
  const [splitMode, setSplitMode] = useState("auto");
  const fileInputRef = useRef(null);
  const pendingFileRef = useRef(null);

  const handleFile = async (file) => {
    pendingFileRef.current = file;
    if (!/\.docx$/i.test(file.name)) {
      setImportState({
        status: "error",
        message:
          `Ce fichier est au format ${file.name.split(".").pop()?.toUpperCase() || "?"}. ` +
          "Seul le .docx (Word récent) est lisible depuis le navigateur. Ouvre le fichier dans Word ou LibreOffice, puis \"Enregistrer sous → .docx\", et réimporte-le ici.",
      });
      return;
    }
    setImportState({ status: "parsing" });
    try {
      const arrayBuffer = await file.arrayBuffer();
      const result = await mammoth.extractRawText({ arrayBuffer });
      const entries = splitIntoEntries(result.value, splitMode);
      setImportPreview({ fileName: file.name, entries, rawText: result.value });
      setImportState({ status: "preview" });
    } catch (e) {
      setImportState({ status: "error", message: "La lecture du fichier a échoué : " + (e?.message || "erreur inconnue") });
    }
  };

  const reparsePreview = (newMode) => {
    setSplitMode(newMode);
    if (importPreview) {
      const entries = splitIntoEntries(importPreview.rawText, newMode);
      setImportPreview({ ...importPreview, entries });
    }
  };

  const confirmImport = async () => {
    if (!importPreview) return;
    const newDoc = {
      id: uid(),
      title: importPreview.fileName.replace(/\.docx$/i, ""),
      importedAt: new Date().toISOString(),
      entries: importPreview.entries,
    };
    const nextDocs = [newDoc, ...docs];
    setDocs(nextDocs);
    setActiveDocId(newDoc.id);
    setActiveEntryId(newDoc.entries[0]?.id || null);
    setShowImport(false);
    setImportState({ status: "idle" });
    setImportPreview(null);
    await persistDoc(newDoc);
    await persistIndex(nextDocs);
    flash(`« ${newDoc.title} » importé — ${newDoc.entries.length} fiche(s)`);
  };

  // ---------- édition ----------
  const updateEntry = async (entryId, patch) => {
    if (!activeDoc) return;
    const nextEntries = activeDoc.entries.map((e) => (e.id === entryId ? { ...e, ...patch } : e));
    const nextDoc = { ...activeDoc, entries: nextEntries };
    setDocs((ds) => ds.map((d) => (d.id === activeDoc.id ? nextDoc : d)));
    await persistDoc(nextDoc);
  };

  const deleteDoc = async (docId) => {
    const nextDocs = docs.filter((d) => d.id !== docId);
    setDocs(nextDocs);
    if (activeDocId === docId) {
      setActiveDocId(nextDocs[0]?.id || null);
      setActiveEntryId(nextDocs[0]?.entries?.[0]?.id || null);
    }
    try {
      await window.storage.delete(`doc:${docId}`);
    } catch {}
    await persistIndex(nextDocs);
    flash("Document supprimé");
  };

  // ---------- images ----------
  const imageInputRef = useRef(null);
  const [attachTargetEntry, setAttachTargetEntry] = useState(null);

  const handleImageUpload = async (files, entryId) => {
    for (const file of files) {
      const dataUrl = await new Promise((res, rej) => {
        const r = new FileReader();
        r.onload = () => res(r.result);
        r.onerror = rej;
        r.readAsDataURL(file);
      });
      const img = { id: uid(), docId: activeDoc.id, entryId, name: file.name, dataUrl };
      setImages((prev) => ({ ...prev, [img.id]: img }));
      try {
        await window.storage.set(`image:${img.id}`, JSON.stringify(img));
      } catch {
        flash("Image trop lourde pour être enregistrée (limite 5 Mo).");
        continue;
      }
      if (entryId) {
        const entry = activeDoc.entries.find((e) => e.id === entryId);
        await updateEntry(entryId, { imageIds: [...(entry.imageIds || []), img.id] });
      }
    }
  };

  const removeImage = async (imgId, entryId) => {
    setImages((prev) => {
      const next = { ...prev };
      delete next[imgId];
      return next;
    });
    try {
      await window.storage.delete(`image:${imgId}`);
    } catch {}
    if (entryId) {
      const entry = activeDoc.entries.find((e) => e.id === entryId);
      if (entry) await updateEntry(entryId, { imageIds: entry.imageIds.filter((i) => i !== imgId) });
    }
  };

  const entryImages = (entry) => (entry?.imageIds || []).map((id) => images[id]).filter(Boolean);

  // ---------------------------------------------------------------
  return (
    <div className="aw-root">
      <style>{`
        .aw-root {
          --paper: #E7DFC6;
          --card: #F6F1E3;
          --ink: #2A2417;
          --ink-faint: #7C7355;
          --stamp: #8A2E2E;
          --stamp-soft: #8A2E2E1a;
          --ledger: #3F5142;
          --hairline: #C9BE9C;
          font-family: 'Source Serif 4', Georgia, serif;
          color: var(--ink);
          background: var(--paper);
          background-image:
            radial-gradient(circle at 15% 0%, #ffffff22 0%, transparent 40%),
            repeating-linear-gradient(0deg, transparent, transparent 39px, #00000006 39px, #00000006 40px);
          min-height: 640px;
          height: 100%;
          display: flex;
          flex-direction: column;
          border-radius: 10px;
          overflow: hidden;
          box-shadow: 0 1px 0 var(--hairline) inset;
        }
        .aw-mono { font-family: 'IBM Plex Mono', ui-monospace, monospace; }
        .aw-topbar {
          display: flex; align-items: center; gap: 12px;
          padding: 14px 18px;
          background: linear-gradient(180deg, #211c11, #2A2417);
          color: #EFE6CC;
          border-bottom: 3px double var(--stamp);
        }
        .aw-brand { display:flex; align-items:center; gap:9px; font-weight:700; letter-spacing:.02em; }
        .aw-brand .stamp-badge {
          width: 26px; height: 26px; border-radius: 50%;
          border: 1.5px solid var(--stamp); color: var(--stamp);
          background: #ffffff10;
          display:flex; align-items:center; justify-content:center;
          font-size: 12px; transform: rotate(-8deg);
        }
        .aw-topbar-title { font-size: 17px; }
        .aw-topbar-sub { font-family:'IBM Plex Mono'; font-size: 10.5px; color:#C9BE9C; letter-spacing:.06em; text-transform:uppercase;}
        .aw-searchwrap { flex:1; display:flex; align-items:center; gap:8px; background:#00000030; border:1px solid #ffffff20; border-radius:7px; padding:7px 10px; max-width: 380px;}
        .aw-searchwrap input { background:transparent; border:none; outline:none; color:#F6F1E3; font-family:'IBM Plex Mono'; font-size:12.5px; width:100%;}
        .aw-searchwrap input::placeholder { color:#a89f7d; }
        .aw-btn {
          font-family:'IBM Plex Mono'; font-size:12px; letter-spacing:.03em;
          display:inline-flex; align-items:center; gap:6px;
          padding: 7px 12px; border-radius:6px; border:1px solid var(--hairline);
          background: var(--card); color: var(--ink); cursor:pointer;
          transition: transform .12s ease, background .15s ease;
        }
        .aw-btn:hover { background:#fffdf5; transform: translateY(-1px); }
        .aw-btn.primary { background: var(--stamp); border-color:var(--stamp); color:#F6EFDD; }
        .aw-btn.primary:hover { background:#7a2727; }
        .aw-btn.ghost { background: transparent; border-color:#ffffff30; color:#EFE6CC; }
        .aw-btn.ghost:hover { background:#ffffff10; }
        .aw-btn:disabled { opacity:.45; cursor:not-allowed; transform:none; }

        .aw-body { flex:1; display:flex; min-height:0; }
        .aw-sidebar {
          width: 300px; flex-shrink:0; border-right: 1px solid var(--hairline);
          background: #DFD5B4; display:flex; flex-direction:column; min-height:0;
        }
        .aw-doclist { padding: 10px; display:flex; flex-direction:column; gap:6px; border-bottom:1px solid var(--hairline); max-height: 33%; overflow-y:auto;}
        .aw-doc-item {
          display:flex; align-items:center; gap:8px; padding:7px 9px; border-radius:6px; cursor:pointer;
          font-size: 13px; border:1px solid transparent;
        }
        .aw-doc-item:hover { background:#00000008; }
        .aw-doc-item.active { background: var(--card); border-color: var(--hairline); font-weight:600; }
        .aw-entrylist { flex:1; overflow-y:auto; padding: 8px; display:flex; flex-direction:column; gap:5px; }
        .aw-entry-item {
          display:flex; gap:8px; align-items:flex-start; padding:8px 9px; border-radius:6px; cursor:pointer;
          border:1px solid transparent;
        }
        .aw-entry-item:hover { background:#00000008; }
        .aw-entry-item.active { background: var(--card); border-color:var(--stamp); }
        .aw-entry-code { font-family:'IBM Plex Mono'; font-size:10.5px; color: var(--stamp); flex-shrink:0; margin-top:1px; min-width: 44px;}
        .aw-entry-title { font-size: 12.5px; line-height:1.35; color: var(--ink); }

        .aw-main { flex:1; overflow-y:auto; min-height:0; }
        .aw-empty { display:flex; flex-direction:column; align-items:center; justify-content:center; height:100%; gap:14px; color: var(--ink-faint); text-align:center; padding: 40px;}

        .aw-page { max-width: 720px; margin: 0 auto; padding: 34px 40px 70px; }
        .aw-crumb { display:flex; align-items:center; gap:8px; margin-bottom: 18px; }
        .aw-crumb button { background:none; border:none; color:var(--ink-faint); cursor:pointer; display:flex; align-items:center; gap:4px; font-family:'IBM Plex Mono'; font-size:11.5px;}
        .aw-crumb button:hover { color: var(--stamp); }

        .aw-entry-header { display:flex; align-items:flex-start; gap:16px; margin-bottom: 6px; }
        .stamp-badge-lg {
          flex-shrink:0; width:58px; height:58px; border-radius:50%;
          border: 2px solid var(--stamp); color: var(--stamp);
          display:flex; align-items:center; justify-content:center; text-align:center;
          font-family:'IBM Plex Mono'; font-size:11px; font-weight:600; transform: rotate(-6deg);
          background: var(--stamp-soft);
        }
        .aw-entry-title-input, .aw-entry-content-input {
          width:100%; border:none; background:transparent; outline:none; color:var(--ink); font-family:'Source Serif 4', serif; resize:vertical;
        }
        .aw-entry-title-input { font-size: 25px; font-weight:700; line-height:1.25; }
        .aw-entry-content-input { font-size: 16.5px; line-height:1.85; min-height: 140px; }
        .aw-entry-title-input:focus, .aw-entry-content-input:focus { outline: 1px dashed var(--hairline); outline-offset: 4px; }
        .aw-divider { border:none; border-top:1px solid var(--hairline); margin: 22px 0; }

        .ref-link {
          font-family:'IBM Plex Mono'; font-size: 0.86em; color: var(--stamp);
          background: var(--stamp-soft); border: none; padding: 1px 5px; border-radius: 4px; cursor:pointer;
          text-decoration: underline dotted; text-underline-offset:3px;
        }
        .ref-link:hover { background: var(--stamp); color:#fff; }

        .aw-section-label { font-family:'IBM Plex Mono'; font-size: 10.5px; letter-spacing:.09em; text-transform:uppercase; color: var(--ink-faint); margin-bottom:10px; display:flex; align-items:center; gap:6px;}
        .aw-chips { display:flex; flex-wrap:wrap; gap:7px; }
        .aw-chip {
          display:inline-flex; align-items:center; gap:5px; font-family:'IBM Plex Mono'; font-size:11.5px;
          padding: 5px 10px; border-radius: 20px; border:1px solid var(--ledger); color: var(--ledger);
          background:#3F51420f; cursor:pointer;
        }
        .aw-chip:hover { background: var(--ledger); color:#fff; }

        .aw-imgrow { display:flex; flex-wrap:wrap; gap:12px; margin-top:6px; }
        .aw-imgcard { position:relative; width:150px; }
        .aw-imgcard img { width:100%; height: 110px; object-fit:cover; border-radius:6px; border:1px solid var(--hairline); background:#fff; }
        .aw-imgcard .rm { position:absolute; top:-7px; right:-7px; background:var(--stamp); color:#fff; border:none; border-radius:50%; width:20px; height:20px; display:flex; align-items:center; justify-content:center; cursor:pointer; }
        .aw-imgcard .cap { font-family:'IBM Plex Mono'; font-size:9.5px; color:var(--ink-faint); margin-top:4px; word-break:break-all;}
        .aw-add-img { width:150px; height:110px; border:1.5px dashed var(--hairline); border-radius:6px; display:flex; flex-direction:column; align-items:center; justify-content:center; gap:5px; cursor:pointer; color:var(--ink-faint); font-family:'IBM Plex Mono'; font-size:10.5px; background:#00000004;}
        .aw-add-img:hover { border-color: var(--stamp); color: var(--stamp); }

        .aw-lecture-entry { margin-bottom: 46px; }
        .aw-lecture-entry .aw-entry-code-tag { font-family:'IBM Plex Mono'; font-size:11px; color:var(--stamp); border-bottom:1px solid var(--stamp); display:inline-block; padding-bottom:1px; margin-bottom:8px;}
        .aw-lecture-entry h2 { font-size:21px; margin: 4px 0 10px; }
        .aw-lecture-entry p { font-size:16px; line-height:1.85; white-space:pre-wrap; }

        .aw-modal-backdrop { position:fixed; inset:0; background:#1a1610cc; display:flex; align-items:center; justify-content:center; z-index:50; padding:20px;}
        .aw-modal { background: var(--card); width:100%; max-width:560px; border-radius:10px; padding:26px; border:1px solid var(--hairline); max-height:85vh; overflow-y:auto;}
        .aw-modal h3 { font-size:19px; margin:0 0 4px; }
        .aw-dropzone { border:2px dashed var(--hairline); border-radius:8px; padding: 30px 16px; text-align:center; cursor:pointer; margin-top:16px; }
        .aw-dropzone:hover { border-color: var(--stamp); }
        .aw-radio-row { display:flex; flex-direction:column; gap:8px; margin-top:14px; }
        .aw-radio-item { display:flex; align-items:flex-start; gap:9px; font-size:13px; cursor:pointer; padding:8px; border-radius:6px; border:1px solid var(--hairline);}
        .aw-radio-item.selected { border-color: var(--stamp); background: var(--stamp-soft); }
        .aw-preview-count { font-family:'IBM Plex Mono'; font-size:12px; color: var(--ledger); margin-top:12px; }
        .aw-error-box { display:flex; gap:9px; align-items:flex-start; background:#8A2E2E14; border:1px solid var(--stamp); color:var(--stamp); padding:12px; border-radius:7px; font-size:12.5px; margin-top:14px; }

        .aw-toast { position:fixed; bottom:20px; left:50%; transform:translateX(-50%); background:#2A2417; color:#F6F1E3; font-family:'IBM Plex Mono'; font-size:12.5px; padding:10px 18px; border-radius:7px; z-index:60; display:flex; align-items:center; gap:8px; box-shadow: 0 4px 20px #0004;}

        .aw-mode-toggle { display:flex; border:1px solid #ffffff30; border-radius:7px; overflow:hidden; }
        .aw-mode-toggle button { font-family:'IBM Plex Mono'; font-size:11.5px; padding:7px 11px; background:transparent; color:#C9BE9C; border:none; cursor:pointer; display:flex; align-items:center; gap:5px;}
        .aw-mode-toggle button.on { background: var(--stamp); color:#F6EFDD; }

        .aw-doc-actions { display:flex; align-items:center; gap:4px; margin-left:auto; }
        .aw-icon-btn { background:none; border:none; cursor:pointer; color: var(--ink-faint); padding:3px; border-radius:4px; display:flex; }
        .aw-icon-btn:hover { color: var(--stamp); background:#00000008;}
      `}</style>

      {/* ---------------- Barre du haut ---------------- */}
      <div className="aw-topbar">
        <div className="aw-brand">
          <span className="stamp-badge">R</span>
          <div>
            <div className="aw-topbar-title">Registre</div>
            <div className="aw-topbar-sub">Lecteur d'archives &amp; renvois</div>
          </div>
        </div>

        <div className="aw-searchwrap">
          <Search size={14} color="#a89f7d" />
          <input
            placeholder="Rechercher un code, un titre, un mot…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        {activeDoc && (
          <div className="aw-mode-toggle">
            <button className={mode === "wiki" ? "on" : ""} onClick={() => setMode("wiki")}>
              <Layers size={13} /> Wiki
            </button>
            <button className={mode === "lecture" ? "on" : ""} onClick={() => setMode("lecture")}>
              <BookOpen size={13} /> Lecture
            </button>
          </div>
        )}

        <button className="aw-btn primary" onClick={() => { setShowImport(true); setImportState({ status: "idle" }); setImportPreview(null); }}>
          <Upload size={13} /> Importer un .docx
        </button>
      </div>

      {!storageOk && (
        <div style={{ background: "#8A2E2E", color: "#F6EFDD", fontFamily: "IBM Plex Mono", fontSize: 11.5, padding: "6px 18px" }}>
          Le stockage n'a pas pu être contacté — tes modifications resteront affichées mais risquent de ne pas être sauvegardées.
        </div>
      )}

      {/* ---------------- Corps ---------------- */}
      <div className="aw-body">
        <div className="aw-sidebar">
          <div className="aw-doclist">
            {docs.length === 0 && loaded && (
              <div style={{ fontSize: 12, color: "var(--ink-faint)", padding: "6px 4px" }}>
                Aucun document. Importe un .docx pour commencer.
              </div>
            )}
            {docs.map((d) => (
              <div key={d.id} className={`aw-doc-item ${d.id === activeDocId ? "active" : ""}`} onClick={() => selectDoc(d.id)}>
                <FileText size={14} color="var(--ledger)" />
                <span style={{ flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{d.title}</span>
                <div className="aw-doc-actions">
                  <button className="aw-icon-btn" title="Supprimer" onClick={(e) => { e.stopPropagation(); if (confirm(`Supprimer « ${d.title} » ?`)) deleteDoc(d.id); }}>
                    <Trash2 size={13} />
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="aw-entrylist">
            {filteredEntries.map((e) => (
              <div key={e.id} className={`aw-entry-item ${e.id === activeEntryId ? "active" : ""}`} onClick={() => goToEntry(e.id)}>
                <span className="aw-entry-code">{e.code || "—"}</span>
                <span className="aw-entry-title">{e.title}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="aw-main">
          {!activeDoc && (
            <div className="aw-empty">
              <LibraryBig size={40} color="var(--hairline)" />
              <div>
                <div style={{ fontSize: 16, fontWeight: 600, marginBottom: 4 }}>Le registre est vide</div>
                <div style={{ fontSize: 13 }}>Importe un fichier .docx pour créer ta première archive consultable.</div>
              </div>
              <button className="aw-btn primary" onClick={() => setShowImport(true)}>
                <Upload size={13} /> Importer un .docx
              </button>
            </div>
          )}

          {activeDoc && mode === "wiki" && (
            activeEntry ? (
              <div className="aw-page">
                <div className="aw-crumb">
                  <button onClick={goBack} disabled={!history.length}>
                    <ArrowLeft size={13} /> Retour
                  </button>
                  <span className="aw-mono" style={{ fontSize: 11, color: "var(--ink-faint)" }}>{activeDoc.title}</span>
                </div>

                <div className="aw-entry-header">
                  <div className="stamp-badge-lg">{activeEntry.code || "FICHE"}</div>
                  <textarea
                    className="aw-entry-title-input"
                    rows={1}
                    value={activeEntry.title}
                    onChange={(e) => updateEntry(activeEntry.id, { title: e.target.value })}
                    onInput={(e) => { e.target.style.height = "auto"; e.target.style.height = e.target.scrollHeight + "px"; }}
                  />
                </div>

                <textarea
                  className="aw-entry-content-input"
                  value={activeEntry.content}
                  onChange={(e) => updateEntry(activeEntry.id, { content: e.target.value })}
                  onFocus={(e) => (e.target.dataset.editing = "1")}
                  style={{ display: activeEntry._editing ? "block" : "none" }}
                />
                {!activeEntry._editing && (
                  <p
                    style={{ fontSize: 16.5, lineHeight: 1.85, whiteSpace: "pre-wrap", cursor: "text" }}
                    onClick={(e) => { e.currentTarget.style.display = "none"; e.currentTarget.nextSibling && (e.currentTarget.nextSibling.style.display = "block"); }}
                  >
                    <LinkedText text={activeEntry.content} codeMap={codeMap} currentEntryId={activeEntry.id} onNavigate={goToEntry} />
                  </p>
                )}
                <textarea
                  className="aw-entry-content-input"
                  style={{ display: "none" }}
                  defaultValue={activeEntry.content}
                  onBlur={(e) => { updateEntry(activeEntry.id, { content: e.target.value }); e.target.style.display = "none"; e.target.previousSibling.style.display = "block"; }}
                />

                <hr className="aw-divider" />

                <div className="aw-section-label"><ImageIcon size={12} /> Images jointes</div>
                <div className="aw-imgrow">
                  {entryImages(activeEntry).map((img) => (
                    <div className="aw-imgcard" key={img.id}>
                      <img src={img.dataUrl} alt={img.name} />
                      <button className="rm" onClick={() => removeImage(img.id, activeEntry.id)}><X size={12} /></button>
                      <div className="cap">{img.name}</div>
                    </div>
                  ))}
                  <label className="aw-add-img">
                    <Plus size={16} />
                    Ajouter
                    <input type="file" accept="image/*" multiple hidden onChange={(e) => e.target.files.length && handleImageUpload(Array.from(e.target.files), activeEntry.id)} />
                  </label>
                </div>

                <hr className="aw-divider" />

                <div className="aw-section-label"><Link2 size={12} /> Renvois détectés dans le texte</div>
                <div className="aw-chips" style={{ marginBottom: 20 }}>
                  {(() => {
                    const codes = [...new Set(allCodesIn(activeEntry.content).map((c) => c.code))].filter(
                      (c) => codeMap.has(c) && codeMap.get(c).id !== activeEntry.id
                    );
                    if (codes.length === 0) return <span style={{ fontSize: 12, color: "var(--ink-faint)" }}>Aucun renvoi détecté.</span>;
                    return codes.map((c) => (
                      <span key={c} className="aw-chip" onClick={() => goToEntry(codeMap.get(c).id)}>
                        <CornerDownRight size={11} /> {c}
                      </span>
                    ));
                  })()}
                </div>

                <div className="aw-section-label"><CornerDownRight size={12} style={{ transform: "scaleX(-1)" }} /> Référencé par</div>
                <div className="aw-chips">
                  {backlinks.length === 0 && <span style={{ fontSize: 12, color: "var(--ink-faint)" }}>Aucune fiche ne renvoie ici pour l'instant.</span>}
                  {backlinks.map((b) => (
                    <span key={b.id} className="aw-chip" onClick={() => goToEntry(b.id)}>{b.code || b.title.slice(0, 24)}</span>
                  ))}
                </div>
              </div>
            ) : (
              <div className="aw-empty">Sélectionne une fiche dans la colonne de gauche.</div>
            )
          )}

          {activeDoc && mode === "lecture" && (
            <div className="aw-page">
              {filteredEntries.map((e) => (
                <div className="aw-lecture-entry" key={e.id} id={`entry-${e.id}`}>
                  {e.code && <span className="aw-entry-code-tag">{e.code}</span>}
                  <h2>{e.title}</h2>
                  <p><LinkedText text={e.content} codeMap={codeMap} currentEntryId={e.id} onNavigate={(id) => goToEntry(id)} /></p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* ---------------- Modal d'import ---------------- */}
      {showImport && (
        <div className="aw-modal-backdrop" onClick={(e) => e.target === e.currentTarget && setShowImport(false)}>
          <div className="aw-modal">
            <h3>Importer un document</h3>
            <div style={{ fontSize: 12.5, color: "var(--ink-faint)", marginBottom: 4 }}>
              Format accepté : .docx (Word récent). Les anciens .doc doivent être ré-enregistrés en .docx au préalable.
            </div>

            {importState.status !== "preview" && (
              <div
                className="aw-dropzone"
                onClick={() => fileInputRef.current?.click()}
                onDragOver={(e) => e.preventDefault()}
                onDrop={(e) => { e.preventDefault(); if (e.dataTransfer.files[0]) handleFile(e.dataTransfer.files[0]); }}
              >
                {importState.status === "parsing" ? (
                  <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 8 }}>
                    <Loader2 size={22} className="aw-spin" />
                    <span className="aw-mono" style={{ fontSize: 12 }}>Analyse du document…</span>
                  </div>
                ) : (
                  <>
                    <Upload size={22} color="var(--ink-faint)" />
                    <div style={{ marginTop: 8, fontSize: 13 }}>Glisse un fichier .docx ici, ou clique pour parcourir</div>
                  </>
                )}
                <input ref={fileInputRef} type="file" accept=".docx" hidden onChange={(e) => e.target.files[0] && handleFile(e.target.files[0])} />
              </div>
            )}

            {importState.status === "error" && (
              <div className="aw-error-box">
                <AlertCircle size={16} style={{ flexShrink: 0 }} />
                <span>{importState.message}</span>
              </div>
            )}

            {importState.status === "preview" && importPreview && (
              <>
                <div className="aw-radio-row">
                  {[
                    ["auto", "Détection automatique des en-têtes", "Repère les codes type « NC 007 / … » et crée une fiche par section."],
                    ["paragraph", "Un paragraphe = une fiche", "Chaque bloc séparé par une ligne vide devient une fiche indépendante."],
                    ["whole", "Document entier", "Garde tout le texte dans une seule fiche, à découper toi-même ensuite."],
                  ].map(([val, label, desc]) => (
                    <label key={val} className={`aw-radio-item ${splitMode === val ? "selected" : ""}`}>
                      <input type="radio" name="splitmode" checked={splitMode === val} onChange={() => reparsePreview(val)} style={{ marginTop: 2 }} />
                      <span>
                        <strong style={{ fontSize: 13 }}>{label}</strong>
                        <br />
                        <span style={{ fontSize: 11.5, color: "var(--ink-faint)" }}>{desc}</span>
                      </span>
                    </label>
                  ))}
                </div>
                <div className="aw-preview-count">
                  <Check size={13} style={{ verticalAlign: "-2px" }} /> {importPreview.entries.length} fiche(s) détectée(s) dans « {importPreview.fileName} »
                </div>
                <div style={{ display: "flex", gap: 8, marginTop: 20, justifyContent: "flex-end" }}>
                  <button className="aw-btn" onClick={() => { setShowImport(false); setImportState({ status: "idle" }); }}>Annuler</button>
                  <button className="aw-btn primary" onClick={confirmImport}>Importer {importPreview.entries.length} fiche(s)</button>
                </div>
              </>
            )}

            {importState.status !== "preview" && (
              <div style={{ display: "flex", justifyContent: "flex-end", marginTop: 16 }}>
                <button className="aw-btn" onClick={() => setShowImport(false)}>Fermer</button>
              </div>
            )}
          </div>
        </div>
      )}

      {toast && <div className="aw-toast"><Check size={13} /> {toast}</div>}

      <style>{`.aw-spin { animation: aw-spin 1s linear infinite; } @keyframes aw-spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}
