# Guide de mise en ligne — Registre

Ce guide t'accompagne pas à pas pour mettre ton application en ligne, avec ton propre nom de domaine. Aucune ligne de commande n'est nécessaire : tout se fait par clics, dans ton navigateur.

Compte à rebours : environ 30 à 45 minutes, réparties en 6 étapes.

---

## Vue d'ensemble

Trois services gratuits vont travailler ensemble :

| Service | Rôle | Coût |
|---|---|---|
| **Supabase** | La base de données qui retient tes documents, fiches et images | Gratuit |
| **GitHub** | Le coffre qui garde le code de ton application | Gratuit |
| **Vercel** | Le service qui héberge et sert ton application au public | Gratuit |
| Ton nom de domaine | déjà en ta possession | — |

---

## Étape 1 — Créer la base de données (Supabase)

1. Va sur **https://supabase.com** et clique sur **"Start your project"**, puis crée un compte (avec Google ou par e-mail).
2. Clique sur **"New project"**.
   - Donne-lui un nom, par exemple `registre`.
   - Choisis un mot de passe pour la base (note-le quelque part, tu n'en auras normalement plus besoin après).
   - Choisis une région proche de toi (par exemple "West EU" si tu es en Afrique centrale ou en Europe).
3. Attends 1 à 2 minutes que le projet se crée.
4. Dans le menu de gauche, clique sur l'icône **"SQL Editor"**.
5. Clique sur **"New query"**, colle exactement ce texte, puis clique sur **"Run"** :

```sql
create table registre_kv (
  key text primary key,
  value text not null,
  updated_at timestamptz default now()
);

alter table registre_kv enable row level security;

create policy "Autoriser l'application" on registre_kv
  for all
  using (true)
  with check (true);
```

   Cela crée la table qui contiendra tes documents, et l'autorise à être lue/écrite par ton application.

   > **Note de confidentialité** : cette configuration est simple et adaptée à un usage privé (toi seul). La clé utilisée par le site est publique par nature (elle circule dans le navigateur), donc quelqu'un qui la trouverait techniquement pourrait accéder à cette table. Pour une archive strictement confidentielle, on pourra ajouter une vraie authentification plus tard — dis-le-moi si tu veux qu'on le fasse.

6. Dans le menu de gauche, clique sur l'icône **"Project Settings"** (roue crantée) puis **"API"**.
7. Note ces deux valeurs, tu en auras besoin à l'étape 3 :
   - **Project URL** (ressemble à `https://xxxxx.supabase.co`)
   - **anon public** (une longue clé qui commence par `eyJ...`)

---

## Étape 2 — Mettre le code sur GitHub

1. Va sur **https://github.com** et crée un compte si tu n'en as pas.
2. Clique sur le **"+"** en haut à droite, puis **"New repository"**.
   - Nom : `registre-webapp`
   - Laisse-le en **"Public"** (ou "Private" si tu préfères, ça ne change rien pour la suite)
   - Ne coche aucune case d'initialisation.
   - Clique sur **"Create repository"**.
3. Sur la page qui s'affiche, clique sur le lien **"uploading an existing file"**.
4. Depuis ton ordinateur, fais glisser **tous les fichiers et dossiers** que je t'ai fournis dans le dossier `registre-webapp` (garde la structure telle quelle : `src/`, `package.json`, `index.html`, etc.) dans la zone de dépôt du navigateur.
5. En bas de page, clique sur **"Commit changes"**.

Ton code est maintenant sur GitHub.

---

## Étape 3 — Déployer sur Vercel

1. Va sur **https://vercel.com** et crée un compte en cliquant sur **"Continue with GitHub"** (le plus simple : ça relie directement les deux services).
2. Une fois connecté, clique sur **"Add New..." → "Project"**.
3. Trouve `registre-webapp` dans la liste et clique sur **"Import"**.
4. Vercel détecte automatiquement qu'il s'agit d'un projet Vite — ne change rien aux réglages de build.
5. Avant de cliquer sur "Deploy", déplie la section **"Environment Variables"** et ajoute les deux valeurs notées à l'étape 1 :

   | Name | Value |
   |---|---|
   | `VITE_SUPABASE_URL` | (ton Project URL Supabase) |
   | `VITE_SUPABASE_ANON_KEY` | (ta clé anon public) |

6. Clique sur **"Deploy"**. Patiente 1 à 2 minutes.
7. Une fois terminé, Vercel t'affiche un lien du type `registre-webapp.vercel.app` — clique dessus : ton application est en ligne.

Teste-la : importe un `.docx`, vérifie qu'il apparaît toujours après avoir rechargé la page (preuve que Supabase sauvegarde bien tes données).

---

## Étape 4 — Relier ton nom de domaine

1. Dans le projet Vercel, va dans l'onglet **"Settings" → "Domains"**.
2. Tape ton nom de domaine (par exemple `mon-registre.com`) et clique sur **"Add"**.
3. Vercel t'indique un ou deux enregistrements DNS à ajouter (en général un enregistrement de type **A** ou **CNAME**, avec une valeur à copier).
4. Va chez ton registrar (l'endroit où tu as acheté ton nom de domaine — OVH, Gandi, Namecheap...), dans la zone de gestion DNS, et ajoute exactement l'enregistrement indiqué par Vercel.
5. Reviens sur Vercel : après quelques minutes (parfois jusqu'à 1h), le domaine passe au vert — c'est en ligne, à ton adresse.

---

## Étape 5 — Importer tes documents

Ouvre ton site à sa nouvelle adresse, et importe tes 13 volumes un par un comme tu l'as fait dans l'aperçu — cette fois, tout est sauvegardé durablement dans Supabase.

---

## Étape 6 — Pour aller plus loin (optionnel)

- **Mettre à jour l'application plus tard** : si je t'aide à améliorer l'app, je te redonnerai les fichiers modifiés ; il suffira de les re-glisser sur GitHub (étape 2) — Vercel republie automatiquement à chaque mise à jour.
- **Vraie confidentialité (mot de passe)** : possible en ajoutant l'authentification Supabase — dis-le-moi si tu veux qu'on l'ajoute.
- **Sauvegarde de secours** : dans Supabase, "Table Editor → registre_kv" te permet d'exporter tes données en CSV à tout moment, en plus de l'application elle-même.

---

Si un écran ne ressemble pas à ce qui est décrit ici (les interfaces évoluent), dis-moi ce que tu vois et je t'aiderai à retrouver le bon bouton.
